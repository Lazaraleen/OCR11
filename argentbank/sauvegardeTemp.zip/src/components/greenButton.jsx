import React from "react";

function GreenButton() {
  return (
    <div className="account-content-wrapper cta">
        <button className="transaction-button">View transactions</button>
    </div>
    )
}

export default GreenButton;
